# <center>TSF TASK 3 - GRIP MARCH'21</center>
# <center>ADITYA AMBWANI<center>

# <center>Exploratory Data Analysis - Retail<center>

### Objective:-
- Perform ‘Exploratory Data Analysis’ on dataset ‘SampleSuperstore'
- As a business manager, try to find out the weak areas where you can work to make more profit.
- What all business problems you can derive by exploring the data?
Ques. What is EDA ?
Ans.  In statistics, exploratory data analysis is an approach to analyzing data sets to summarize their main characteristics,         often using statistical graphics and other data visualization methods. A statistical model can be used or not, but             primarily EDA is for seeing what the data can tell us beyond the formal modeling or hypothesis testing task.

```python
# importing libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')
```


```python
# Reading dataset
data=pd.read_csv("SampleSuperstore.csv")
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Ship Mode</th>
      <th>Segment</th>
      <th>Country</th>
      <th>City</th>
      <th>State</th>
      <th>Postal Code</th>
      <th>Region</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Second Class</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>Kentucky</td>
      <td>42420</td>
      <td>South</td>
      <td>Furniture</td>
      <td>Bookcases</td>
      <td>261.9600</td>
      <td>2</td>
      <td>0.00</td>
      <td>41.9136</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Second Class</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>Kentucky</td>
      <td>42420</td>
      <td>South</td>
      <td>Furniture</td>
      <td>Chairs</td>
      <td>731.9400</td>
      <td>3</td>
      <td>0.00</td>
      <td>219.5820</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Second Class</td>
      <td>Corporate</td>
      <td>United States</td>
      <td>Los Angeles</td>
      <td>California</td>
      <td>90036</td>
      <td>West</td>
      <td>Office Supplies</td>
      <td>Labels</td>
      <td>14.6200</td>
      <td>2</td>
      <td>0.00</td>
      <td>6.8714</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Standard Class</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>Florida</td>
      <td>33311</td>
      <td>South</td>
      <td>Furniture</td>
      <td>Tables</td>
      <td>957.5775</td>
      <td>5</td>
      <td>0.45</td>
      <td>-383.0310</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Standard Class</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>Florida</td>
      <td>33311</td>
      <td>South</td>
      <td>Office Supplies</td>
      <td>Storage</td>
      <td>22.3680</td>
      <td>2</td>
      <td>0.20</td>
      <td>2.5164</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>9989</th>
      <td>Second Class</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Miami</td>
      <td>Florida</td>
      <td>33180</td>
      <td>South</td>
      <td>Furniture</td>
      <td>Furnishings</td>
      <td>25.2480</td>
      <td>3</td>
      <td>0.20</td>
      <td>4.1028</td>
    </tr>
    <tr>
      <th>9990</th>
      <td>Standard Class</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Costa Mesa</td>
      <td>California</td>
      <td>92627</td>
      <td>West</td>
      <td>Furniture</td>
      <td>Furnishings</td>
      <td>91.9600</td>
      <td>2</td>
      <td>0.00</td>
      <td>15.6332</td>
    </tr>
    <tr>
      <th>9991</th>
      <td>Standard Class</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Costa Mesa</td>
      <td>California</td>
      <td>92627</td>
      <td>West</td>
      <td>Technology</td>
      <td>Phones</td>
      <td>258.5760</td>
      <td>2</td>
      <td>0.20</td>
      <td>19.3932</td>
    </tr>
    <tr>
      <th>9992</th>
      <td>Standard Class</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Costa Mesa</td>
      <td>California</td>
      <td>92627</td>
      <td>West</td>
      <td>Office Supplies</td>
      <td>Paper</td>
      <td>29.6000</td>
      <td>4</td>
      <td>0.00</td>
      <td>13.3200</td>
    </tr>
    <tr>
      <th>9993</th>
      <td>Second Class</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Westminster</td>
      <td>California</td>
      <td>92683</td>
      <td>West</td>
      <td>Office Supplies</td>
      <td>Appliances</td>
      <td>243.1600</td>
      <td>2</td>
      <td>0.00</td>
      <td>72.9480</td>
    </tr>
  </tbody>
</table>
<p>9994 rows × 13 columns</p>
</div>




```python
# Checking for rows and coloumns
data.shape
```




    (9994, 13)




```python
# describing the dataset in summarized way
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Postal Code</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>9994.000000</td>
      <td>9994.000000</td>
      <td>9994.000000</td>
      <td>9994.000000</td>
      <td>9994.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>55190.379428</td>
      <td>229.858001</td>
      <td>3.789574</td>
      <td>0.156203</td>
      <td>28.656896</td>
    </tr>
    <tr>
      <th>std</th>
      <td>32063.693350</td>
      <td>623.245101</td>
      <td>2.225110</td>
      <td>0.206452</td>
      <td>234.260108</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1040.000000</td>
      <td>0.444000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>-6599.978000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>23223.000000</td>
      <td>17.280000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>1.728750</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>56430.500000</td>
      <td>54.490000</td>
      <td>3.000000</td>
      <td>0.200000</td>
      <td>8.666500</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>90008.000000</td>
      <td>209.940000</td>
      <td>5.000000</td>
      <td>0.200000</td>
      <td>29.364000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>99301.000000</td>
      <td>22638.480000</td>
      <td>14.000000</td>
      <td>0.800000</td>
      <td>8399.976000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# More information about dataset
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 9994 entries, 0 to 9993
    Data columns (total 13 columns):
     #   Column        Non-Null Count  Dtype  
    ---  ------        --------------  -----  
     0   Ship Mode     9994 non-null   object 
     1   Segment       9994 non-null   object 
     2   Country       9994 non-null   object 
     3   City          9994 non-null   object 
     4   State         9994 non-null   object 
     5   Postal Code   9994 non-null   int64  
     6   Region        9994 non-null   object 
     7   Category      9994 non-null   object 
     8   Sub-Category  9994 non-null   object 
     9   Sales         9994 non-null   float64
     10  Quantity      9994 non-null   int64  
     11  Discount      9994 non-null   float64
     12  Profit        9994 non-null   float64
    dtypes: float64(3), int64(2), object(8)
    memory usage: 1015.1+ KB
    


```python
# Checking for null values in our dataset
data.isnull().sum()
```




    Ship Mode       0
    Segment         0
    Country         0
    City            0
    State           0
    Postal Code     0
    Region          0
    Category        0
    Sub-Category    0
    Sales           0
    Quantity        0
    Discount        0
    Profit          0
    dtype: int64




```python
# Listing all coloumns in our dataset
data.columns
```




    Index(['Ship Mode', 'Segment', 'Country', 'City', 'State', 'Postal Code',
           'Region', 'Category', 'Sub-Category', 'Sales', 'Quantity', 'Discount',
           'Profit'],
          dtype='object')




```python
# Checking for duplicate values in our dataset
data.duplicated().sum()
```




    17




```python
# Removing all the duplicate values
data.drop_duplicates(keep=False,inplace=True)
```


```python
data.shape
```




    (9960, 13)




```python
#EDA
sns.kdeplot(data['Sales'],color='cyan',label='Sales',bw=50)
sns.kdeplot(data['Profit'],color='red',label='Profit',bw=50)
plt.legend()
```




    <matplotlib.legend.Legend at 0x4fdcb66dc0>




    
![png](output_14_1.png)
    


Conclusion:- We can infer from above graph that profit is more than sales in general


```python
# Finding Outliers
df = pd.DataFrame(data = data, columns = ['Profit','Sales'])
sns.boxplot(x="variable", y="value", data=pd.melt(df))
df.plot(kind='box')
```




    <AxesSubplot:>




    
![png](output_16_1.png)
    



    
![png](output_16_2.png)
    



```python
# Visualising data by plotting histograms
data.hist(bins=100,figsize=(20,20))
plt.show()
```


    
![png](output_17_0.png)
    



```python
# Analysing the data based on Ship Mode
sns.pairplot(data,hue="Ship Mode")
```




    <seaborn.axisgrid.PairGrid at 0x4fdcef1ca0>




    
![png](output_18_1.png)
    



```python
# Analysing the data based on Ship Mode
sns.countplot(x='Ship Mode',data=data)
```




    <AxesSubplot:xlabel='Ship Mode', ylabel='count'>




    
![png](output_19_1.png)
    


Conclusion:- The preffered ship mode is Standard Class.


```python
# Analysing the data based on Ship Mode
dataf=data.groupby(['Ship Mode'])[['Profit','Discount','Sales']].mean()
dataf.plot.pie(subplots=True,figsize=(25,25),labels=dataf.index)
```




    array([<AxesSubplot:ylabel='Profit'>, <AxesSubplot:ylabel='Discount'>,
           <AxesSubplot:ylabel='Sales'>], dtype=object)




    
![png](output_21_1.png)
    


Conclusion:- The profit and sales are high in first class while discount is high in Standard Class.


```python
# Analysing the data based on State data
sns.pairplot(data,hue='State')
```




    <seaborn.axisgrid.PairGrid at 0x4fdcd23610>




    
![png](output_23_1.png)
    



```python
# Analysing the data based on State data
plt.figure(figsize=(25,25))
sns.countplot(x='State',data=data)
plt.show()
```


    
![png](output_24_0.png)
    



```python
# Analysing the data based on Profit in each State
dataf1=data.groupby(['State'])[['Profit','Discount','Sales']].mean()
dataf11=dataf1.sort_values('Profit')
dataf11[['Profit']].plot(kind='bar')
plt.xlabel('States')
plt.ylabel('Profit by State')
plt.show()
```


    
![png](output_25_0.png)
    


Conclusion:- The highest profit is in Vermont State.


```python
# Analysing the data based on Sale in each State
dataf12=dataf1.sort_values('Sales')
dataf12[['Sales']].plot(kind='bar')
plt.xlabel('States')
plt.ylabel('Sales by State')
plt.show()
```


    
![png](output_27_0.png)
    


Conclusion:- The highest sales is in Wyoming State.


```python
# Analysing the data based on Discount in each State
dataf13=dataf1.sort_values('Discount')
dataf12[['Discount']].plot(kind='bar')
plt.xlabel('State')
plt.ylabel('Disount by State')
plt.show()
```


    
![png](output_29_0.png)
    


Conclusion:- The highest discount is in Illinois State.


```python
# Analysing the data based on Region data
sns.pairplot(data,hue='Region')
```




    <seaborn.axisgrid.PairGrid at 0x4fdd05fa90>




    
![png](output_31_1.png)
    



```python
# Analysing the data based on Region data
sns.countplot(x='Region',data=data)
plt.show()
```


    
![png](output_32_0.png)
    


Conclusion:- The West has highest number of dealings.


```python
# Analysing the data based on Region
dataf2=data.groupby(['Region'])[['Profit','Discount','Sales']].mean()
dataf2.plot.pie(subplots=True,figsize=(25,25),labels=dataf2.index)
```




    array([<AxesSubplot:ylabel='Profit'>, <AxesSubplot:ylabel='Discount'>,
           <AxesSubplot:ylabel='Sales'>], dtype=object)




    
![png](output_34_1.png)
    


Conclusion:- Profit is highest in East. Discount is highest in Central region. East also has highest number of Sales.


```python
# Analysing the data based on Segment data
sns.pairplot(data,hue='Segment')
```




    <seaborn.axisgrid.PairGrid at 0x4fd9c57640>




    
![png](output_36_1.png)
    



```python
# Analysing the data based on Segment data
sns.countplot(x='Segment',data=data)
plt.show()
```


    
![png](output_37_0.png)
    


Conclusion:- THe segment which buys more product lie in Consumer section.


```python
# Analysing the data based on Segment
dataf3=data.groupby(['Segment'])[['Profit','Discount','Sales']].mean()
dataf3.plot.pie(subplots=True,figsize=(25,25),labels=dataf3.index)
```




    array([<AxesSubplot:ylabel='Profit'>, <AxesSubplot:ylabel='Discount'>,
           <AxesSubplot:ylabel='Sales'>], dtype=object)




    
![png](output_39_1.png)
    


Conclusion:- Profit is highest in home-office as well as sales are also highest here.


```python
# Analysing the data based on Quantity data
sns.pairplot(data,hue='Quantity')
```




    <seaborn.axisgrid.PairGrid at 0x4fe8453dc0>




    
![png](output_41_1.png)
    



```python
# Analysing the data based on Quantity data
sns.countplot(x='Quantity',data=data)
plt.show()
```


    
![png](output_42_0.png)
    



```python
# Analysing the data based on Quantity
dataf4=data.groupby(['Quantity'])[['Profit','Discount','Sales']].mean()
dataf4.plot.pie(subplots=True,figsize=(25,25))
```




    array([<AxesSubplot:ylabel='Profit'>, <AxesSubplot:ylabel='Discount'>,
           <AxesSubplot:ylabel='Sales'>], dtype=object)




    
![png](output_43_1.png)
    



```python
# Analysing the data based on Category data
sns.pairplot(data,hue='Category')
```




    <seaborn.axisgrid.PairGrid at 0x4fe90edcd0>




    
![png](output_44_1.png)
    



```python
# Analysing the data based on Category data
sns.countplot(x='Category',data=data)
plt.show()
```


    
![png](output_45_0.png)
    


Conclusion:- Office Supplies are more compared to furniture and technology.


```python
# Analysing the data based on Category
dataf5=data.groupby(['Category'])[['Profit','Discount','Sales']].mean()
dataf5.plot.pie(subplots=True,figsize=(25,25),labels=dataf5.index)
```




    array([<AxesSubplot:ylabel='Profit'>, <AxesSubplot:ylabel='Discount'>,
           <AxesSubplot:ylabel='Sales'>], dtype=object)




    
![png](output_47_1.png)
    


Conclusion:- Profit is highest in Technology and also the most number of sales.


```python
# Analysing the data based on Sub-Category data
sns.pairplot(data,hue='Sub-Category')
```




    <seaborn.axisgrid.PairGrid at 0x4feb47bdc0>




    
![png](output_49_1.png)
    



```python
# Analysing the data based on Sub-Category data
sns.countplot(x='Sub-Category',data=data)
plt.show()
```


    
![png](output_50_0.png)
    

